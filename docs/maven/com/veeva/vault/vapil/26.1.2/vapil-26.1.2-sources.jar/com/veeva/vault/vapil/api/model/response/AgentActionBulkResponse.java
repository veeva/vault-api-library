/*---------------------------------------------------------------------
 *	Copyright (c) 2024 Veeva Systems Inc.  All Rights Reserved.
 *	This code is based on pre-existing content developed and
 *	owned by Veeva Systems Inc. and may only be used in connection
 *	with the deliverable with which it was provided to Customer.
 *---------------------------------------------------------------------
 */
package com.veeva.vault.vapil.api.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.veeva.vault.vapil.api.model.VaultModel;

import java.util.List;

/**
 * Model for the following API calls responses:
 * <p>
 * GET /api/{version}/services/ai/agent_actions
 */
public class AgentActionBulkResponse extends VaultResponse {

    @JsonProperty("agents")
    public List<Agent> getAgents() {
        return (List<Agent>) this.get("agents");
    }

    public void setAgents(List<Agent> agents) {
        this.set("agents", agents);
    }

    public static class Agent extends VaultModel {

        @JsonProperty("agentName")
        public String getAgentName() {
            return this.getString("agentName");
        }

        public void setAgentName(String agentName) {
            this.set("agentName", agentName);
        }

        @JsonProperty("agentLabel")
        public String getAgentLabel() {
            return this.getString("agentLabel");
        }

        public void setAgentLabel(String agentLabel) {
            this.set("agentLabel", agentLabel);
        }

        @JsonProperty("description")
        public String getDescription() {
            return this.getString("description");
        }

        public void setDescription(String description) {
            this.set("description", description);
        }

        @JsonProperty("actions")
        public List<AgentAction> getActions() {
            return (List<AgentAction>) this.get("actions");
        }

        public void setActions(List<AgentAction> actions) {
            this.set("actions", actions);
        }

        public static class AgentAction extends VaultModel {

            @JsonProperty("name")
            public String getName() {
                return this.getString("name");
            }

            public void setName(String name) {
                this.set("name", name);
            }

            @JsonProperty("label")
            public String getLabel() {
                return this.getString("label");
            }

            public void setLabel(String label) {
                this.set("label", label);
            }

            @JsonProperty("url")
            public String getUrl() {
                return this.getString("url");
            }

            public void setUrl(String url) {
                this.set("url", url);
            }

            @JsonProperty("description")
            public String getDescription() {
                return this.getString("description");
            }

            public void setDescription(String description) {
                this.set("description", description);
            }
        }
    }
}
