/**
 * Methods to perform Vault API calls, with each method mapping to a Vault API endpoint
 * <p>
 * For example, ObjectRecordRequest.retrieveObjectRecord(recordId) maps to
 * <a href='https://developer.veevavault.com/api/21.1/#retrieve-object-record'>https://developer.veevavault.com/api/21.1/#retrieve-object-record</a>
 */
package com.veeva.vault.vapil.api.request;
